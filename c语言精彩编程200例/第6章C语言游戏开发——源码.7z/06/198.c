
#include <dos.h>
#include <stdio.h>
#include <ctype.h>
#include <conio.h>
#include <bios.h>
#include <alloc.h>


/*  �����ά����ghouse����¼��Ļ�ϸ����״̬��
���У�0��ʾʲô��û�У�'b'��ʾ���ӣ�'w'��ʾǽ�ڣ�'m'��ʾĿ�ĵأ�'i'��ʾ������Ŀ�ĵء� */
char ghouse[20][20];

/*  ���º���Ϊֱ��д�������� */
char far *screen=(char far* )0xb8000000;
void putchxy(int y,int x,char ch,char fc,char bc)
{
  screen[(x*160)+(y<<1)+0]=ch;
  screen[(x*160)+(y<<1)+1]=(bc*16)+fc;
}

/* �����ж��Ƿ�ʤ�������ݽṹ */
typedef struct winer {
  int x,y;
  struct winer *p;
}winer;

/* ����λ�õ����ݽṹ */
typedef struct boxs {
 int x,y;
 struct boxs *next;
}boxs;

/* ���ض��������ϻ�ǽ�ڲ��������¼״̬�ĺ��� */
void printwall(int x,int y)
{
    putchxy(y-1,x-1,219,RED,WHITE);
    ghouse[x][y]='w';
}

/* ���ض��������ϻ����Ӳ��������¼״̬�ĺ��� */
void printbox(int x,int y)
{
   putchxy(y-1,x-1,10,WHITE,BLACK);
   ghouse[x][y]='b';
}

/* ���ض��������ϻ�Ŀ�ĵز��������¼״̬�ĺ��� */
void printwhither1(int x,int y,winer  **win,winer **pw)
{
   winer *qw;
   putchxy(y-1,x-1,'*',YELLOW,BLACK);
   ghouse[x][y]='m';
   if(*win==NULL)
   {
     *win=*pw=qw=(winer* )malloc(sizeof(winer));
     (*pw)->x=x;(*pw)->y=y;(*pw)->p=NULL;
   }
   else
   {
     qw=(winer* )malloc(sizeof(winer));
     qw->x=x;qw->y=y;
     (*pw)->p=qw;(*pw)=qw;qw->p=NULL;
   }
}


/* ���ض��������ϻ�Ŀ�ĵز��������¼״̬�ĺ��� */
void printwhither(int x,int y)
{
   putchxy(y-1,x-1,'*',YELLOW,BLACK);
   ghouse[x][y]='m';
}
/* ���ض��������ϻ��˵ĺ��� */
void printman(int x,int y)
{
   gotoxy(y,x);
   _AL=02;_CX=01;_AH=0xa;
   geninterrupt(0x10);
}

/* ���ض��������ϻ�������Ŀ�ĵ��ϲ��������¼״̬�ĺ��� */
void printboxin(int x,int y)
{
     putchxy(y-1,x-1,10,YELLOW,BLACK);
     ghouse[x][y]='i';
}

/* ��ʼ����������ʼ���������Ļ */
void init()
{
  int i,j;
  for(i=0;i<20;i++)
    for(j=0;j<20;j++)
        ghouse[i][j]=0;
        _AL=3;
        _AH=0;
              geninterrupt(0x10);
        gotoxy(30,4);
           printf("Welcome to BIGBOX world!");
        gotoxy(30,6);
           printf("You can press up,down,left,right to control.");
        gotoxy(30,8);
           printf("Press Esc to quit it.");
        gotoxy(30,10);
           printf("Press space to reset the game."); 
}

/* ��һ�ص�ͼ���ʼ�� */
winer *inithouse1()
{
  int x,y;
  winer *win=NULL,*pw;
  for(x=1,y=5;y<=9;y++)
       printwall(x+4,y+10);
  for(y=5,x=2;x<=5;x++)
       printwall(x+4,y+10);
  for(y=9,x=2;x<=5;x++)
       printwall(x+4,y+10);
  for(y=1,x=3;x<=8;x++)
       printwall(x+4,y+10);
  for(x=3,y=3;x<=5;x++)
       printwall(x+4,y+10);
  for(x=5,y=8;x<=9;x++)
       printwall(x+4,y+10);
  for(x=7,y=4;x<=9;x++)
       printwall(x+4,y+10);
  for(x=9,y=5;y<=7;y++)
       printwall(x+4,y+10);
  for(x=8,y=2;y<=3;y++)
       printwall(x+4,y+10);
  printwall(5+4,4+10);
  printwall(5+4,7+10);
  printwall(3+4,2+10);
  printbox(3+4,6+10);
  printbox(3+4,7+10);
  printbox(4+4,7+10);
  printwhither1(4+4,2+10,&win,&pw);
  printwhither1(5+4,2+10,&win,&pw);
  printwhither1(6+4,2+10,&win,&pw);
  printman(2+4,8+10);
  return win;
}

/* �ڶ��ص�ͼ���ʼ�� */
winer *inithouse2()
{     
      int x,y;
      winer *win=NULL,*pw;
      for(x=1,y=4;y<=7;y++)
          printwall(x+4,y+10);
      for(x=2,y=2;y<=4;y++)
          printwall(x+4,y+10);
      for(x=2,y=7;x<=4;x++)
          printwall(x+4,y+10);
      for(x=4,y=1;x<=8;x++)
          printwall(x+4,y+10);
      for(x=8,y=2;y<=8;y++)
          printwall(x+4,y+10);
      for(x=4,y=8;x<=8;x++)
          printwall(x+4,y+10);
      for(x=4,y=6;x<=5;x++)
          printwall(x+4,y+10);
      for(x=3,y=2;x<=4;x++)
          printwall(x+4,y+10);
      for(x=4,y=4;x<=5;x++)
          printwall(x+4,y+10);
          printwall(6+4,3+10);
      printbox(3+4,5+10);
      printbox(6+4,6+10);
      printbox(7+4,3+10);
      printwhither1(5+4,7+10,&win,&pw);
      printwhither1(6+4,7+10,&win,&pw);
      printwhither1(7+4,7+10,&win,&pw);
      printman(2+4,6+10);
      return win;
}
/* �����ص�ͼ���ʼ�� */
winer *inithouse3()
{
      int x,y;
      winer *win=NULL,*pw;
      for(x=1,y=2;y<=8;y++)
          printwall(x+4,y+10);
      for(x=2,y=2;x<=4;x++)
          printwall(x+4,y+10);
      for(x=4,y=1;y<=3;y++)
          printwall(x+4,y+10);
      for(x=5,y=1;x<=8;x++)
          printwall(x+4,y+10);
      for(x=8,y=2;y<=5;y++)
          printwall(x+4,y+10);
      for(x=5,y=5;x<=7;x++)
          printwall(x+4,y+10);
      for(x=7,y=6;y<=9;y++)
          printwall(x+4,y+10);
      for(x=3,y=9;x<=6;x++)
          printwall(x+4,y+10);
      for(x=3,y=6;y<=8;y++)
          printwall(x+4,y+10);
  printwall(2+4,8+10);
  printwall(5+4,7+10);
  printbox(6+4,3+10);
  printbox(4+4,4+10);
  printbox(5+4,6+10);
  printwhither1(2+4,5+10,&win,&pw);
  printwhither1(2+4,6+10,&win,&pw);
  printwhither1(2+4,7+10,&win,&pw);
  printman(2+4,4+10);
  return win;
}
/* ���Ĺص�ͼ���ʼ�� */
winer *inithouse4()
{
  int x,y;
  winer *win=NULL,*pw;
  for(x=1,y=1;y<=6;y++)
     printwall(x+4,y+10);
  for(x=2,y=7;y<=8;y++)
     printwall(x+4,y+10);
  for(x=2,y=1;x<=7;x++)
     printwall(x+4,y+10);
  for(x=7,y=2;y<=4;y++)
     printwall(x+4,y+10);
  for(x=6,y=4;y<=9;y++)
     printwall(x+4,y+10);
  for(x=3,y=9;x<=5;x++)
     printwall(x+4,y+10);
  for(x=3,y=3;y<=4;y++)
     printwall(x+4,y+10);
  printwall(3+4,8+10);
  printbox(3+4,5+10);
  printbox(4+4,4+10);
  printbox(4+4,6+10);
  printbox(5+4,5+10);
  printbox(5+4,3+10);
  printwhither1(3+4,7+10,&win,&pw);
  printwhither1(4+4,7+10,&win,&pw);
  printwhither1(5+4,7+10,&win,&pw);
  printwhither1(4+4,8+10,&win,&pw);
  printwhither1(5+4,8+10,&win,&pw);
  printman(2+4,2+10);
  return win;
}

/* �ƶ��ڿյ��ϵ����ӵ��յ��� */
movebox(int x,int y,char a)
{
  switch(a)
  {
    case 'u':ghouse[x-1][y]=0;
        printf(" ");
        printbox(x-2,y);
        printman(x-1,y);
        ghouse[x-2][y]='b';
        break;
    case 'd':ghouse[x+1][y]=0;
        printf(" ");
        printbox(x+2,y); 
        printman(x+1,y);
        ghouse[x+2][y]='b';
        break;
    case 'l':ghouse[x][y-1]=0;
        printf(" ");
        printbox(x,y-2);
        printman(x,y-1);
        ghouse[x][y-2]='b';
        break;
    case 'r':ghouse[x][y+1]=0;
        printf(" ");
        printbox(x,y+2);
        printman(x,y+1);
        ghouse[x][y+2]='b';
        break;
    default: break;
  }
}

/* �ƶ���Ŀ�ĵ��ϵ����ӵ��յ��� */
moveinbox(int x,int y,char a)
{
  switch(a)
  {
    case 'u':ghouse[x-1][y]='m';
        printf(" ");
        printbox(x-2,y);
        printman(x-1,y);
        ghouse[x-2][y]='b';
        break;
    case 'd':ghouse[x+1][y]='m';
        printf(" ");
        printbox(x+2,y);
        printman(x+1,y);
        ghouse[x+2][y]='b';
        break;
    case 'l':ghouse[x][y-1]='m';
        printf(" ");
        printbox(x,y-2);
        printman(x,y-1);
        ghouse[x][y-2]='b';
        break;
    case 'r':ghouse[x][y+1]='m';
        printf(" ");
        printbox(x,y+2);
        printman(x,y+1);
        ghouse[x][y+2]='b';
        break;
    default: break;
  }
}

/* �ƶ��ڿյ��ϵ����ӵ�Ŀ�ĵ��� */
moveboxin(int x,int y,char a)
{
  switch(a)
  {
    case 'u':ghouse[x-1][y]=0;
        printf(" ");
        printboxin(x-2,y);
        printman(x-1,y);
        ghouse[x-2][y]='i';
        break;
    case 'd':ghouse[x+1][y]=0;
        printf(" ");
        printboxin(x+2,y);
        printman(x+1,y);
        ghouse[x+2][y]='i';
        break;
    case 'l':ghouse[x][y-1]=0;
        printf(" ");
        printboxin(x,y-2);
        printman(x,y-1);
        ghouse[x][y-2]='i';
        break;
    case 'r':ghouse[x][y+1]=0;
        printf(" ");
        printboxin(x,y+2);
        printman(x,y+1);
        ghouse[x][y+2]='i';
        break;
    default: break;
  }
}

/* �ƶ���Ŀ�ĵ��ϵ����ӵ�Ŀ�ĵ� */
moveinboxin(int x,int y,char a)
{
  switch(a)
  {
    case 'u':ghouse[x-1][y]='m';
         printf(" ");
         printboxin(x-2,y);
         printman(x-1,y);
         ghouse[x-2][y]='i';
         break;
    case 'd':ghouse[x+1][y]='m';printf(" ");
         printboxin(x+2,y);
         printman(x+1,y);
         ghouse[x+2][y]='i';
         break;
    case 'l':ghouse[x][y-1]='m';
         printf(" ");
         printboxin(x,y-2);
         printman(x,y-1);
         ghouse[x][y-2]='i';
         break;
    case 'r':ghouse[x][y+1]='m';
         printf(" ");
         printboxin(x,y+2);
         printman(x,y+1);
         ghouse[x][y+2]='i';
         break;
    default: break;
  }
}

/* �ж��ض��������ϵ�״̬ */
int judge(int x,int y)
{
   int i;
   switch(ghouse[x][y])
   {
      case  0:   i=1;break;
      case 'w': i=0;break;
      case 'b': i=2;break;
      case 'i': i=4;break;
      case 'm': i=3;break;
      default: break;
   }
    return i;
}

/* �������¼��̺�,�����ƶ��������� */
move(int x,int y,char a)
{
   switch(a)
   {
     case 'u':if(!judge(x-1,y)) 
              {
                  gotoxy(y,x);
                  break;
              }
              else if(judge(x-1,y)==1||judge(x-1,y)==3)
              {
                   if(judge(x,y)==3)
                   { 
                     printwhither(x,y);
                     printman(x-1,y);
                     break;
                     }
                     else
                     {
                         printf(" ");
                         printman(x-1,y);
                         break;
                     }
              }
              else if(judge(x-1,y)==2)
               {
                   if(judge(x-2,y)==1)
                   {
                       movebox(x,y,'u');
                       if(judge(x,y)==3) 
                           printwhither(x,y); 
                           gotoxy(y,x-1);
                   }
                   else if(judge(x-2,y)==3)
                   {
                        moveboxin(x,y,'u');
                        if(judge(x,y)==3)
                        printwhither(x,y);
                        gotoxy(y,x-1);
                   }
                   else gotoxy(y,x);
                        break;
               }
               else if(judge(x-1,y)==4)
               { 
                    if(judge(x-2,y)==1)
                    {
                        moveinbox(x,y,'u');
                        if(judge(x,y)==3) 
                        printwhither(x,y);
                        gotoxy(y,x-1);
                    }
                    else if(judge(x-2,y)==3)
                    { 
                         moveinboxin(x,y,'u');
                         if(judge(x,y)==3) 
                         printwhither(x,y);
                         gotoxy(y,x-1);
                    }
                    else gotoxy(y,x);
                         break;
               }
     case 'd':if(!judge(x+1,y)) 
              {
                  gotoxy(y,x);
                  break;
              }
              else if(judge(x+1,y)==1||judge(x+1,y)==3)
              {
                   if(judge(x,y)==3)
                   { 
                       printwhither(x,y);
                       printman(x+1,y);
                       break;
                   }
                   else
                   {
                       printf(" ");
                       printman(x+1,y);
                       break;
                   }
               }
              else if(judge(x+1,y)==2)
               { 
                   if(judge(x+2,y)==1)
                   {
                       movebox(x,y,'d');
                       if(judge(x,y)==3) 
                       printwhither(x,y);
                       gotoxy(y,x+1);
                   }
                   else if(judge(x+2,y)==3)
                   {
                        moveboxin(x,y,'d');
                        if(judge(x,y)==3) 
                        printwhither(x,y);
                        gotoxy(y,x+1);
                  }
                  else gotoxy(y,x);
                        break;
               }
               else if(judge(x+1,y)==4)
               { 
                   if(judge(x+2,y)==1)
                   {
                       moveinbox(x,y,'d');
                       if(judge(x,y)==3) 
                       printwhither(x,y);
                       gotoxy(y,x+1);
                   }
                   else if(judge(x+2,y)==3)
                   {
                        moveinboxin(x,y,'d');
                        if(judge(x,y)==3) 
                        printwhither(x,y);
                        gotoxy(y,x+1);
                   }
                   else 
                        gotoxy(y,x);
                        break;
               }

     case 'l':if(!judge(x,y-1))  
              {
                  gotoxy(y,x);
                  break;
              }
              else if(judge(x,y-1)==1||judge(x,y-1)==3)
              {
                   if(judge(x,y)==3)
                   { 
                       printwhither(x,y);
                       printman(x,y-1);
                       break;
                   }
                   else
                   {
                       printf(" ");
                       printman(x,y-1);
                       break;}
                   }
              else if(judge(x,y-1)==2)
              { 
                   if(judge(x,y-2)==1)
                   {
                       movebox(x,y,'l');
                       if(judge(x,y)==3) 
                       printwhither(x,y); 
                       gotoxy(y-1,x);
                   }
                   else if(judge(x,y-2)==3)
                   {
                        moveboxin(x,y,'l');
                        if(judge(x,y)==3) 
                        printwhither(x,y);  
                        gotoxy(y-1,x);
                   }
                   else 
                        gotoxy(y,x);
                        break;
               }
               else if(judge(x,y-1)==4)
               { 
                   if(judge(x,y-2)==1)
                   {
                       moveinbox(x,y,'l');
                       if(judge(x,y)==3)
                       printwhither(x,y); 
                       gotoxy(y-1,x);
                   }
                   else if(judge(x,y-2)==3)
                   {
                        moveinboxin(x,y,'l');
                        if(judge(x,y)==3) 
                        printwhither(x,y);  
                        gotoxy(y-1,x);
                  }
                  else gotoxy(y,x);
                        break;
               }
               
     case 'r':if(!judge(x,y+1))  
              {
                  gotoxy(y,x);
                  break;
              }
              else if(judge(x,y+1)==1||judge(x,y+1)==3)
              {
                  if(judge(x,y)==3)
                  {
                      printwhither(x,y);
                      printman(x,y+1);
                      break;
                  }
                  else
                  {
                      printf(" ");
                      printman(x,y+1);
                      break;
                  }
               }
               else if(judge(x,y+1)==2)
               { 
                    if(judge(x,y+2)==1)
                    {
                        movebox(x,y,'r');
                        if(judge(x,y)==3) 
                        printwhither(x,y); 
                        gotoxy(y+1,x);
                     }
                     else if(judge(x,y+2)==3)
                     {
                         moveboxin(x,y,'r');
                         if(judge(x,y)==3) 
                         printwhither(x,y);  
                         gotoxy(y+1,x);
                      }
                      else 
                         gotoxy(y,x);
                         break;
               }
               else if(judge(x,y+1)==4)
               { 
                    if(judge(x,y+2)==1)
                    {
                         moveinbox(x,y,'r');
                         if(judge(x,y)==3) 
                         printwhither(x,y); 
                         gotoxy(y+1,x);
                      }
                      else if(judge(x,y+2)==3)
                      {
                           moveinboxin(x,y,'r');
                           if(judge(x,y)==3)
                           printwhither(x,y);  
                           gotoxy(y+1,x);
                       }
                       else 
                            gotoxy(y,x);
                            break;
               }
        default: break;
   }
}

/* ���¿ո����,�ص����ؿ�ͷ�ĺ��� */
void reset(int i)
{
     switch(i)
     {
              case 0:  init();
                   inithouse1();break;
              case 1:  init();
                   inithouse2();break;
              case 2:  init();
                   inithouse3();break;
              case 3:  init();
                   inithouse4();break;  
              default:break;
     }
}

/* ������main */
void main()
{
   int key,x,y,s,i=0;
   winer *win,*pw;
   _AL=3;_AH=0;
   geninterrupt(0x10);
   init();
   win=inithouse1();
   do{
          _AH=3;
          geninterrupt(0x10);
          x=_DH+1;y=_DL+1;
          while(bioskey(1)==0);
          key=bioskey(0);
          switch(key)
          {
              case 0x4800:move(x,y,'u');break; /* �������ϼ��� */
              case 0x5000:move(x,y,'d');break; /* �������¼��� */
              case 0x4b00:move(x,y,'l');break; /* ����������� */
              case 0x4d00:move(x,y,'r');break; /* �������Ҽ��� */
              case 0x3920:reset(i);break;      /* ���¿ո���� */
              default:break;
          }
          s=0;
          pw=win;
          while(pw)
          {
              if(ghouse[pw->x][pw->y]=='m') 
                  s++;
                  pw=pw->p;
          }
          if(s==0)
          {
                  free(win);
                  gotoxy(25,2);
                  printf("congratulate! you did a good job!");
                  getch();
                  i++;
          switch(i)
          {
                   case 1:  init();
                        win=inithouse2();break;
                   case 2:  init();
                        win=inithouse3();break;
                   case 3:  init();
                        win=inithouse4();break;
                   case 4:  gotoxy(15,21);
                        printf("My god, You are a god-man! You can play again!");
                        key=0x011b;getch();break;
                   default: break;
          }
     }
   }while(key!=0x011b);

   _AL=3;
   _AH=0;
   geninterrupt(0x10);
}
